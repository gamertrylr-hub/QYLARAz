# Estado da memória e dos pesos — QYLARA V7

## Implementado no código-fonte
- Memória pessoal persistente no diretório privado `filesDir/qylara_memory/user_memory.json`.
- Salvamento somente por comando explícito do usuário (`lembre que:`, `lembre-se que:`, `guarde na memória:`).
- Remoção por comando explícito (`esqueça:`, `apague da memória:`).
- Limite de 1.200 caracteres por memória e deduplicação normalizada.
- Recuperação lexical das memórias relevantes e inclusão como contexto adicional para o motor local.
- A memória é independente dos pesos e funciona como armazenamento, não como treino neural.

## Segurança
- Dados ficam na área privada do aplicativo; não são publicados nem sincronizados por esta funcionalidade.
- Conteúdo recuperado é delimitado como dado/contexto e explicitamente não deve ser tratado como instrução.
- Não há alteração automática de pesos, nem autoexecução de comandos derivados da memória.
- Para apagar dados, use `esqueça:` ou limpe os dados do app nas configurações Android.

## Não concluído / não comprovado
- `tokenizer.qytok` e `weights.qyweights` não estão incluídos; o modelo neural não pode ser declarado funcional.
- Não foi feita compilação APK nem teste em dispositivo nesta alteração.
- Não existe treinamento/fine-tuning automático; isso só deve ser adicionado depois de escolher modelo, formato, licença, pipeline e conjunto de avaliação.
- A memória usa correspondência lexical simples, não busca semântica por embeddings.
