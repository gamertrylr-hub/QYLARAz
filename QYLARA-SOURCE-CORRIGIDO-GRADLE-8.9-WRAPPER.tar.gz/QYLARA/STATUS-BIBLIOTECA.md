# Biblioteca QYLARA — estado deste pacote

## V7 — roteamento e estilo de resposta
- Roteamento local-first por padrão; web-first para pesquisa explícita e informação recente.
- Fallback para web quando a biblioteca não retorna material relevante.
- Aritmética simples é respondida localmente (por exemplo, “2 mais 2 é 4.”).
- Removidas as frases metalinguísticas “Pesquisei na internet...” e “Consultei a biblioteca local...”.
- Os resultados web mantêm título, trecho e URL para permitir verificação, sem introdução repetitiva.

## Incluído
- Busca offline por palavras-chave em 27 entradas educacionais iniciais, em 17 áreas/assuntos.
- Conteúdo-base em português em `app/src/main/assets/knowledge/library.json`.
- Catálogo de fontes externas de conhecimento aberto em `app/src/main/assets/knowledge/catalog.json`.
- Botão `+` da conversa abre o seletor de documentos do Android.
- Importação para armazenamento privado de TXT, MD, HTML e HTM (máximo 20 MB por arquivo).
- A biblioteca é consultada antes do fallback web para perguntas que não foram classificadas como recentes/pesquisa explícita.
- Se os pesos QYWT existirem, os trechos locais são enviados ao modelo como contexto.

## Limitações não ocultadas
- Esta não é uma enciclopédia completa e não contém todo o conhecimento do mundo.
- Os acervos completos da Wikipédia e livros didáticos são demasiado grandes para serem embutidos no pacote de código; alguns podem ter vários GB. O catálogo dá acesso às fontes oficiais e cada licença deve ser respeitada.
- Este leitor ainda não indexa diretamente PDF, EPUB ou ZIM. Converta/exporte para texto quando a licença permitir.
- O núcleo neural continua sem `weights.qyweights` e `tokenizer.qytok` neste pacote V7. A biblioteca faz recuperação de informação, não substitui um modelo neural treinado.
- Não foi possível compilar o APK neste ambiente porque não há instalação de Gradle/Android SDK disponível aqui. A validação realizada neste pacote é estática e de integridade dos dados.

- O roteamento é heurístico nesta versão; ainda não é uma decisão semântica equivalente a um LLM treinado. A ausência de pesos permanece uma limitação importante.
