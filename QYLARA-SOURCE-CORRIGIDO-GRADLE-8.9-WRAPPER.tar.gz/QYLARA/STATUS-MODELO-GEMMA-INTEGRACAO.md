# QYLARA + Gemma 4 E2B — integração de código

## O que foi alterado neste pacote
- Adicionada a dependência Android Kotlin do LiteRT-LM para inferência no próprio processo do aplicativo.
- Adicionado `GemmaModelStore`: download iniciado pelo usuário, armazenamento privado em `filesDir/qylara_models/gemma4-e2b`, arquivo parcial separado e verificação de tamanho antes da instalação.
- O motor de inferência foi trocado para usar `Engine`/`Conversation` do LiteRT-LM com o arquivo `.litertlm`; não usa Python, Termux, servidor local ou serviço de inferência remoto em runtime.
- A interface tem ação explícita para baixar os pesos (cerca de 2,58 GB) e exibe progresso. Após o download, o modelo fica armazenado dentro dos dados privados da QYLARA e pode ser usado offline.
- Memória pessoal e biblioteca documental continuam separadas dos pesos: os seus conteúdos entram como contexto quando relevantes, não modificam automaticamente a rede neural.

## Limites honestos
- O arquivo de pesos não é embutido no APK, pois acrescentaria cerca de 2,58 GB ao pacote. Ele passa a fazer parte dos dados privados da instalação QYLARA depois do download inicial.
- O primeiro download requer internet, espaço livre e que o repositório/modelo esteja acessível. Se o Hugging Face exigir aceite de licença/autenticação ou o nome do artefato variar, a instalação exibirá erro em vez de marcar o modelo como pronto.
- A alteração do código ainda precisa de compilação Gradle e teste real em aparelho Android. Não afirmar APK compilado nem inferência validada até executar esses testes.
- A integração não treina automaticamente os pesos. Treinamento/ajuste futuro precisa de dados autorizados, pipeline de treinamento, avaliação e rollback; isso não deve acontecer silenciosamente no telefone.
- O backend CPU é usado por padrão para maximizar compatibilidade. GPU/NPU devem ser habilitados depois de validar suporte no dispositivo-alvo.

## Referência oficial
- Google AI Edge, LiteRT-LM Android Kotlin: https://developers.google.com/edge/litert-lm/android
- Gemma 4 / LiteRT-LM: https://developers.google.com/edge/litert-lm/models/gemma-4
