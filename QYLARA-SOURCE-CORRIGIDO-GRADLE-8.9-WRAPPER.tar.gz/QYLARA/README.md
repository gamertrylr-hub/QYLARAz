# QYLARA V7 — Projeto Android ARM64

Este pacote contém o código-fonte do aplicativo Android QYLARA: interface Kotlin/Jetpack Compose, recursos locais, biblioteca de conhecimento, pesquisa web por HTTPS e executor nativo C/C++ integrado ao Android.

## Plataforma-alvo

- Aplicativo Android; ABI nativa configurada exclusivamente para `arm64-v8a`.
- Código nativo compilado como biblioteca Android pelo Gradle + Android NDK + CMake.
- O APK instalado não inicia servidor local e não depende de um ambiente de desenvolvimento instalado no telefone.
- Não há executáveis Linux para computador, Windows/macOS, nem bibliotecas nativas x86 ou x86_64 neste pacote.

## Compilação

A compilação exige Gradle, Android SDK, Android NDK e CMake compatíveis com Android. Essas ferramentas são necessárias somente para construir o APK. O pacote não inclui toolchains de computador nem binários de compilação de host.

## Recursos incluídos

- Interface QYLARA V7 com ações rápidas e compositor de conversa.
- Biblioteca local inicial e importação de TXT, MD, HTML e HTM para armazenamento privado do aplicativo.
- Pesquisa web nativa por HTTPS, quando há conexão.
- Verificação inicial de afirmações com relatório de evidências, fontes, incerteza e histórico persistente privado.
- Ponte JNI/C++ para o núcleo local.
- Configuração de compilação nativa limitada a `arm64-v8a`.

## Limitações atuais

O modelo Gemma 4 E2B agora tem integração de código via LiteRT-LM e um fluxo explícito para baixar os pesos para o armazenamento privado da QYLARA. Os pesos não ficam embutidos no APK. A integração ainda precisa de compilação Gradle e teste em aparelho; portanto, este pacote ainda não comprova um APK funcional. O roteamento atual usa regras e recuperação de conteúdo; a pesquisa web apresenta resultados e trechos, não garante síntese avançada.

A validação do código-fonte não equivale a uma compilação ou teste completo do APK em dispositivo.

## Memória persistente segura (incremental)

A biblioteca de documentos já persiste os arquivos importados na área privada do app. Esta versão também inclui memória pessoal explícita: para salvar uma informação, envie uma mensagem começando com `lembre que:`, `lembre-se que:` ou `guarde na memória:`. Para apagar, use `esqueça:` seguido do trecho que identifica a memória. Os dados ficam no armazenamento privado do aplicativo e não são enviados para a web por esse recurso.

A memória recupera fatos por correspondência textual; isso **não altera os pesos neurais nem equivale a treinamento**. O Gemma é um modelo externo de pesos abertos integrado ao aplicativo, enquanto a orquestração, a memória e a biblioteca permanecem componentes da QYLARA. A evolução segura dos pesos exige artefatos compatíveis, treinamento controlado, avaliação de regressões e possibilidade de rollback; não há auto-treinamento em segundo plano.

## Limites de validação

Foi acrescentado código-fonte para memória explícita e recuperação de contexto, mas a compilação Android e os testes em dispositivo ainda precisam ser executados num ambiente com Android SDK/NDK compatíveis. Não trate o projeto como APK validado até esses testes passarem.


## Verificação de informações (incremental)

O comando `Verifique se é verdade: [afirmação]` aciona o verificador de evidências e guarda o relatório localmente. `histórico de verificações` lista as verificações recentes. Esta primeira implementação é heurística e utiliza títulos/resumos de busca; não garante a verdade de uma afirmação nem substitui a leitura de fontes primárias. Detalhes e limitações estão em `STATUS-VERIFICACAO-EVIDENCIAS.md`. A compilação e os testes no Android permanecem pendentes.
