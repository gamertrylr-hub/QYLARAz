# QYLARA — Verificação de evidências (implementação inicial)

## O que foi acrescentado
- `QylaraTruthVerifier.kt`: consulta resultados de busca, mede correspondência textual com a afirmação, identifica sinais textuais de apoio/contestação e classifica o resultado com linguagem cautelosa.
- Registra afirmação, status, data, títulos, URLs e trechos numa memória privada `filesDir/qylara_knowledge/verification_history.json` (limite de 300 verificações).
- `QylaraWebResearch.searchResults`: expõe os resultados estruturados usados pelo verificador.
- `LocalQylaraEngine`: encaminha comandos explícitos de verificação para o novo fluxo e oferece consulta ao histórico.

## Comandos reconhecidos nesta versão
- `Verifique se é verdade: [afirmação]`
- `É verdade que [afirmação]?`
- `Confirme a informação: [afirmação]`
- `Cheque os fatos: [afirmação]`
- `histórico de verificações`

## Limitações conhecidas — importante
- Esta é uma triagem heurística inicial baseada em títulos e snippets de um mecanismo de busca. Não lê o conteúdo completo das páginas, não verifica documentos primários e não prova se uma afirmação é verdadeira ou falsa.
- Os indicadores de apoio/contestação são pistas textuais, não um detector confiável de verdade. O sistema explicita essa limitação e prefere “não verificado” ou “evidências insuficientes”.
- Ainda não foram adicionados testes instrumentados no Android, nem executada compilação Gradle ou validação em aparelho. Este pacote é código-fonte, não APK validado.
- Próxima etapa técnica: implementar leitura segura de páginas relevantes, deduplicação por origem, classificação de fontes por domínio/tipo, comparação explícita de evidências e testes com conjuntos rotulados de afirmações verdadeiras, falsas e inconclusivas.
