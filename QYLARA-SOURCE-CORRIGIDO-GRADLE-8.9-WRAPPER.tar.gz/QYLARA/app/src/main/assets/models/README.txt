QYLARA AI CORE — ARTEFATO NATIVO ANDROID

Este diretório guarda os metadados do núcleo QYLARA. Os pesos treinados e o tokenizer final ainda não estão incluídos.

A biblioteca nativa `libqylara_core.so` é gerada durante a compilação Android por Gradle, Android NDK e CMake, para a ABI `arm64-v8a`.

O aplicativo instalado usa os componentes empacotados no APK; não inicia servidor local nem requer ferramentas de desenvolvimento durante a execução.
