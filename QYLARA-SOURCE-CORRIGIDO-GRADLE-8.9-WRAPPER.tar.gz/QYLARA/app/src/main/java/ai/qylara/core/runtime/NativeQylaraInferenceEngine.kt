package ai.qylara.core.runtime

import android.content.Context
import com.google.ai.edge.litertlm.Engine
import com.google.ai.edge.litertlm.EngineConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/** Gemma inference runs inside the QYLARA Android process using LiteRT-LM. */
class NativeQylaraInferenceEngine(
    context: Context,
    private val modelFile: File = GemmaModelStore(context).modelFile
) : QylaraInferenceEngine {
    @Volatile private var engine: Engine? = null

    private fun getEngine(): Engine {
        engine?.let { return it }
        synchronized(this) {
            engine?.let { return it }
            check(modelFile.isFile && modelFile.length() >= 1_000_000_000L) {
                "O modelo Gemma 4 E2B ainda não foi instalado. Use ‘Instalar modelo Gemma’ na QYLARA."
            }
            return Engine(EngineConfig(modelPath = modelFile.absolutePath)).also {
                it.initialize()
                engine = it
            }
        }
    }

    override suspend fun generate(prompt: String, maxTokens: Int): String = withContext(Dispatchers.IO) {
        require(prompt.isNotBlank()) { "Prompt vazio." }
        require(maxTokens in 1..2048) { "maxTokens deve estar entre 1 e 2048." }
        val model = getEngine()
        model.createConversation().use { conversation ->
            conversation.sendMessage(prompt).toString().trim().ifBlank {
                "O modelo não produziu uma resposta. Tente novamente."
            }
        }
    }

    override fun close() {
        synchronized(this) {
            runCatching { engine?.close() }
            engine = null
        }
    }
}
