package ai.qylara.app.runtime

import android.content.Context
import android.net.Uri
import org.json.JSONObject
import java.io.File
import java.text.Normalizer
import java.util.Locale

/** Offline-first knowledge retrieval. Ships a small licensed/educational starter corpus and accepts user-selected text documents. */
internal class QylaraKnowledgeLibrary(private val context: Context) {
    data class Entry(val title: String, val subject: String, val text: String, val keywords: List<String>, val source: String)

    private val importedDir = File(context.filesDir, "qylara_knowledge/imported").apply { mkdirs() }
    @Volatile private var cached: List<Entry>? = null

    fun search(question: String, limit: Int = 4): String? {
        val terms = tokens(question).filter { it.length > 2 }.toSet()
        if (terms.isEmpty()) return null
        val ranked = allEntries().map { entry ->
            val titleTokens = tokens(entry.title + " " + entry.subject + " " + entry.keywords.joinToString(" ")).toSet()
            val bodyTokens = tokens(entry.text).toSet()
            val titleHits = terms.intersect(titleTokens).size
            val bodyHits = terms.intersect(bodyTokens).size
            val phraseBonus = if (normalize(entry.title).contains(normalize(question))) 5 else 0
            entry to (titleHits * 4 + bodyHits + phraseBonus)
        }.filter { it.second >= 3 }.sortedByDescending { it.second }.take(limit)
        if (ranked.isEmpty()) return null
        return buildString {
            ranked.forEachIndexed { index, pair ->
                val entry = pair.first
                if (ranked.size > 1) append(entry.title).append('\n')
                append(entry.text.take(1800)).append("\n")
                if (entry.source.isNotBlank()) append("Fonte: ").append(entry.source).append("\n")
                if (index != ranked.lastIndex) append('\n')
            }
        }.trim()
    }

    @Synchronized fun importDocument(uri: Uri, displayName: String?): String {
        val resolvedName = runCatching {
            context.contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) cursor.getString(0) else null
            }
        }.getOrNull()
        val name = (resolvedName ?: displayName ?: "documento.txt").substringAfterLast('/').take(120)
        val ext = name.substringAfterLast('.', "").lowercase(Locale.ROOT)
        require(ext in setOf("txt", "md", "html", "htm")) { "Formato não suportado. Importe TXT, MD ou HTML." }
        val bytes = context.contentResolver.openInputStream(uri)?.use { input ->
            val out = java.io.ByteArrayOutputStream()
            val buffer = ByteArray(8192)
            var total = 0
            while (true) {
                val n = input.read(buffer)
                if (n < 0) break
                total += n
                require(total <= 20 * 1024 * 1024) { "O arquivo excede o limite de 20 MB." }
                out.write(buffer, 0, n)
            }
            out.toByteArray()
        } ?: error("Não foi possível abrir o arquivo selecionado.")
        var text = bytes.toString(Charsets.UTF_8)
        if (ext == "html" || ext == "htm") text = text.replace(Regex("(?is)<(script|style)[^>]*>.*?</\\1>"), " ").replace(Regex("(?is)<[^>]+>"), " ")
        text = text.replace(Regex("\\s+"), " ").trim()
        require(text.length >= 30) { "O arquivo não contém texto suficiente para indexar." }
        val safeName = name.replace(Regex("[^A-Za-z0-9._-]"), "_").take(90)
        val outFile = File(importedDir, "${System.currentTimeMillis()}_$safeName.txt")
        outFile.writeText(text, Charsets.UTF_8)
        cached = null
        return "Biblioteca ampliada: '$name' foi importado e ficará disponível offline."
    }

    fun importedCount(): Int = importedDir.listFiles()?.count { it.isFile } ?: 0

    private fun allEntries(): List<Entry> {
        cached?.let { return it }
        val seed = context.assets.open("knowledge/library.json").bufferedReader(Charsets.UTF_8).use { JSONObject(it.readText()) }
        val array = seed.optJSONArray("items")
        val entries = mutableListOf<Entry>()
        if (array != null) for (i in 0 until array.length()) {
            val item = array.getJSONObject(i)
            val keys = item.optJSONArray("keywords")
            entries += Entry(item.optString("title"), item.optString("subject"), item.optString("text"),
                (0 until (keys?.length() ?: 0)).map { keys!!.optString(it) }, item.optString("source"))
        }
        importedDir.listFiles()?.filter { it.isFile && it.extension == "txt" }?.forEach { file ->
            val content = runCatching { file.readText(Charsets.UTF_8) }.getOrDefault("")
            if (content.isNotBlank()) {
                val chunks = content.chunked(1600)
                chunks.forEachIndexed { index, chunk ->
                    entries += Entry(file.nameWithoutExtension + if (chunks.size > 1) " (${index + 1})" else "", "Documento importado", chunk, emptyList(), "Arquivo local: ${file.nameWithoutExtension}")
                }
            }
        }
        return entries.also { cached = it }
    }

    private fun tokens(value: String): List<String> = normalize(value).split(Regex("[^a-z0-9]+" )).filter { it.isNotBlank() }
    private fun normalize(value: String): String = Normalizer.normalize(value.lowercase(Locale.ROOT), Normalizer.Form.NFD).replace(Regex("\\p{Mn}+"), "")
}
