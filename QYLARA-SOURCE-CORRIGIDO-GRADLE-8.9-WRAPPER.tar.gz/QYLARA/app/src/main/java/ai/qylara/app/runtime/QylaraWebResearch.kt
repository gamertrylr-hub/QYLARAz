package ai.qylara.app.runtime

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/** Native, runtime-only web research. It has no Termux/Python/backend dependency. */
internal class QylaraWebResearch {
    data class Result(val title: String, val snippet: String, val url: String)

    suspend fun searchResults(question: String, limit: Int = 5): List<Result> = withContext(Dispatchers.IO) {
        require(question.isNotBlank()) { "Digite o que a QYLARA deve pesquisar." }
        val endpoint = "https://html.duckduckgo.com/html/?q=" + URLEncoder.encode(question, "UTF-8")
        parseResults(request(endpoint)).take(limit)
    }

    suspend fun search(question: String, limit: Int = 5): String {
        val results = searchResults(question, limit)
        if (results.isEmpty()) return "Não encontrei fontes suficientes para responder com segurança. Tente reformular a pergunta."
        return buildString {
            results.forEach { item ->
                append(item.title).append('\n')
                if (item.snippet.isNotBlank()) append(item.snippet).append('\n')
                append(item.url).append("\n\n")
            }
        }.trim()
    }

    private fun request(address: String): String {
        val connection = (URL(address).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 10000
            readTimeout = 12000
            setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 Chrome/124 Mobile Safari/537.36 QYLARA/1.0")
            setRequestProperty("Accept", "text/html,application/xhtml+xml")
            instanceFollowRedirects = true
        }
        try {
            val code = connection.responseCode
            if (code !in 200..299) throw IllegalStateException("O mecanismo de pesquisa respondeu HTTP $code.")
            return connection.inputStream.bufferedReader(Charsets.UTF_8).use { reader ->
                val out = StringBuilder()
                val buffer = CharArray(8192)
                var total = 0
                while (true) {
                    val count = reader.read(buffer)
                    if (count < 0) break
                    total += count
                    if (total > 1_500_000) break
                    out.append(buffer, 0, count)
                }
                out.toString()
            }
        } finally {
            connection.disconnect()
        }
    }

    private fun parseResults(html: String): List<Result> {
        val anchors = Regex("(?is)<a\\b[^>]*class=[\"'][^\"']*result__a[^\"']*[\"'][^>]*>.*?</a>")
        val snippets = Regex("(?is)<(?:a|div)[^>]*class=[\"'][^\"']*result__snippet[^\"']*[\"'][^>]*>(.*?)</(?:a|div)>")
            .findAll(html).map { clean(it.groupValues[1]) }.toList()
        return anchors.findAll(html).mapNotNull { match ->
            val tag = match.value
            val href = Regex("(?is)href=[\"']([^\"']+)[\"']").find(tag)?.groupValues?.get(1) ?: return@mapNotNull null
            val title = clean(tag.substringAfter('>').substringBeforeLast("</a>"))
            val url = normalizeUrl(href)
            if (title.isBlank() || !url.startsWith("http")) return@mapNotNull null
            Result(title, snippets.getOrNull(countResultsBefore(html, match.range.first)) ?: "", url)
        }.distinctBy { it.url }.toList()
    }

    private fun countResultsBefore(html: String, offset: Int): Int =
        Regex("(?is)<a\\b[^>]*class=[\"'][^\"']*result__a[^\"']*[\"'][^>]*>.*?</a>")
            .findAll(html.substring(0, offset)).count()

    private fun normalizeUrl(raw: String): String {
        val decoded = decodeEntities(raw)
        val redirect = Regex("[?&]uddg=([^&]+)").find(decoded)?.groupValues?.get(1)
        return if (redirect != null) runCatching { java.net.URLDecoder.decode(redirect, "UTF-8") }.getOrDefault(decoded) else decoded
    }

    private fun clean(raw: String): String = decodeEntities(raw.replace(Regex("(?is)<[^>]+>"), " "))
        .replace(Regex("\\s+"), " ").trim()

    private fun decodeEntities(value: String): String = value
        .replace("&amp;", "&").replace("&quot;", "\"").replace("&#39;", "'")
        .replace("&lt;", "<").replace("&gt;", ">").replace("&nbsp;", " ")
}
