package ai.qylara.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.SettingsSuggest
import androidx.compose.material.icons.filled.TipsAndUpdates
import androidx.compose.material.icons.filled.Download
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Button
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import ai.qylara.app.runtime.LocalQylaraEngine
import ai.qylara.app.ui.QylaraTheme
import ai.qylara.core.runtime.QylaraCoreCatalog
import kotlinx.coroutines.launch
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private data class ChatMessage(val text: String, val fromUser: Boolean)
private data class QuickAction(val title: String, val subtitle: String, val prompt: String, val icon: androidx.compose.ui.graphics.vector.ImageVector, val tint: Color)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { QylaraApp() }
    }
}

@Composable
private fun QylaraApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val engine = remember { LocalQylaraEngine(context, QylaraCoreCatalog.standard) }
    DisposableEffect(engine) { onDispose { engine.close() } }

    val messages = remember {
        mutableStateListOf(
            ChatMessage("Olá! Eu sou a QYLARA.", false),
            ChatMessage("Como posso ajudar você hoje?", false)
        )
    }
    var input by remember { mutableStateOf("") }
    var processing by remember { mutableStateOf(false) }
    var modelDownload by remember { mutableStateOf(false) }
    var modelProgress by remember { mutableStateOf(0f) }
    var modelStatus by remember { mutableStateOf(if (engine.modelStore.isInstalled) "Modelo Gemma instalado · pronto para uso offline" else "Modelo neural ainda não instalado · download aproximado de 2,6 GB") }
    val scope = rememberCoroutineScope()
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            val result = runCatching { engine.importKnowledge(uri, uri.lastPathSegment ?: "documento.txt") }
                .getOrElse { "Não foi possível importar o arquivo: ${it.message ?: "formato inválido"}" }
            messages += ChatMessage(result, false)
        }
    }

    fun sendMessage(raw: String) {
        val text = raw.trim()
        if (text.isEmpty() || processing) return
        messages += ChatMessage(text, true)
        input = ""
        processing = true
        scope.launch {
            val result = try { engine.generate(text, 256) }
            catch (error: Exception) { "Não consegui concluir agora. ${error.message ?: "Tente novamente."}" }
            processing = false
            messages += ChatMessage(result, false)
        }
    }

    QylaraTheme {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            Column(Modifier.fillMaxSize().imePadding()) {
                TopBar()
                CoverBanner()
                Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)) {
                    Text(modelStatus, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    if (modelDownload) LinearProgressIndicator(progress = { modelProgress }, modifier = Modifier.fillMaxWidth().padding(top = 6.dp))
                    if (!engine.modelStore.isInstalled) Button(
                        onClick = {
                            if (!modelDownload) scope.launch {
                                modelDownload = true
                                modelStatus = "Baixando pesos do Gemma 4 E2B… mantenha espaço livre de pelo menos 3 GB."
                                try {
                                    withContext(Dispatchers.IO) {
                                        engine.modelStore.download { done, total ->
                                            modelProgress = if (total > 0) done.toFloat() / total else 0f
                                        }
                                    }
                                    modelStatus = "Gemma instalado na QYLARA · pronto para inferência local"
                                    messages += ChatMessage("Modelo Gemma 4 E2B instalado no armazenamento privado da QYLARA. O download foi concluído; a primeira carga pode levar alguns segundos.", false)
                                } catch (e: Exception) {
                                    modelStatus = "Falha ao instalar modelo: ${e.message ?: "erro de rede ou acesso"}"
                                    messages += ChatMessage(modelStatus, false)
                                } finally { modelDownload = false }
                            }
                        }, enabled = !modelDownload, modifier = Modifier.fillMaxWidth().padding(top = 6.dp)
                    ) { Icon(Icons.Default.Download, null); Spacer(Modifier.width(8.dp)); Text(if (modelDownload) "Baixando modelo…" else "Instalar modelo Gemma (≈ 2,6 GB)") }
                }
                QuickActions(onChoose = { sendMessage(it) })
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 2.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.AutoAwesome, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(7.dp))
                    Text("SEU ESPAÇO DE CONVERSA", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.weight(1f))
                    Text("Core + Web", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.secondary)
                }
                LazyColumn(
                    modifier = Modifier.weight(1f).fillMaxWidth().padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    item { Spacer(Modifier.height(2.dp)) }
                    items(messages) { MessageBubble(it) }
                    if (processing) item { TypingIndicator() }
                    item { Spacer(Modifier.height(4.dp)) }
                }
                Composer(
                    value = input,
                    onValueChange = { input = it },
                    enabled = !processing,
                    onImport = { importLauncher.launch(arrayOf("text/plain", "text/markdown", "text/html", "application/xhtml+xml")) },
                    onSend = { sendMessage(input) }
                )
            }
        }
    }
}

@Composable
private fun TopBar() {
    Row(
        Modifier.fillMaxWidth().padding(start = 18.dp, end = 14.dp, top = 9.dp, bottom = 7.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(42.dp).clip(RoundedCornerShape(14.dp)).background(Brush.linearGradient(listOf(Color(0xFF2F8BFF), Color(0xFF8B45FF)))), contentAlignment = Alignment.Center) {
            Text("Q", color = Color.White, fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.headlineSmall)
        }
        Column(Modifier.padding(start = 10.dp).weight(1f)) {
            Text("QYLARA", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.onBackground)
            Text("Sua assistente inteligente", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Surface(shape = RoundedCornerShape(20.dp), color = Color(0xFF102A35)) {
            Row(Modifier.padding(horizontal = 10.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(7.dp).clip(CircleShape).background(Color(0xFF4BE3A4)))
                Spacer(Modifier.width(6.dp))
                Text("Online", color = Color(0xFF8CEBC8), style = MaterialTheme.typography.labelMedium)
            }
        }
        IconButton(onClick = { }) { Icon(Icons.Default.SettingsSuggest, "Configurações", tint = MaterialTheme.colorScheme.onSurfaceVariant) }
    }
}

@Composable
private fun CoverBanner() {
    Box(
        Modifier.fillMaxWidth().padding(horizontal = 14.dp).height(142.dp).clip(RoundedCornerShape(22.dp))
    ) {
        Image(
            painter = painterResource(R.drawable.qylara_cover), contentDescription = "Arte de capa da QYLARA",
            modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop
        )
        Box(Modifier.fillMaxSize().background(Brush.horizontalGradient(listOf(Color(0xD9080D1B), Color(0x12080D1B), Color(0xAA080D1B)))))
        Column(Modifier.align(Alignment.CenterStart).padding(start = 17.dp, end = 130.dp)) {
            Text("CONHECIMENTO.\nIDEIAS. POSSIBILIDADES.", color = Color.White, fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(6.dp))
            Text("Vamos descobrir algo novo?", color = Color(0xFFB8D7FF), style = MaterialTheme.typography.bodySmall)
            Spacer(Modifier.height(10.dp))
            Surface(shape = RoundedCornerShape(20.dp), color = Color(0xC8206DEB)) {
                Row(Modifier.padding(horizontal = 10.dp, vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.AutoAwesome, null, tint = Color.White, modifier = Modifier.size(14.dp))
                    Spacer(Modifier.width(5.dp))
                    Text("QYLARA AI", color = Color.White, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun QuickActions(onChoose: (String) -> Unit) {
    val actions = listOf(
        QuickAction("Pesquisar na web", "Informações atuais", "Pesquise na web informações atuais sobre um assunto importante.", Icons.Default.Public, Color(0xFF48B8FF)),
        QuickAction("Biblioteca", "Aprender algo", "Explique um assunto usando conhecimento confiável e exemplos.", Icons.Default.MenuBook, Color(0xFF55D9B5)),
        QuickAction("Estudar", "Aulas e exercícios", "Me ajude a estudar um tema com explicação e exercícios.", Icons.Default.School, Color(0xFFB69AFF)),
        QuickAction("Calculadora", "Fazer uma conta", "Me ajude a resolver um cálculo.", Icons.Default.Calculate, Color(0xFFFFC35D)),
        QuickAction("Explorar", "Ideias e dicas", "Me dê ideias interessantes para explorar e aprender.", Icons.Default.Explore, Color(0xFFFF83C8)),
        QuickAction("Dica do dia", "Uma curiosidade", "Conte uma curiosidade interessante e explique por que ela é verdadeira.", Icons.Default.TipsAndUpdates, Color(0xFF6EDCFF))
    )
    Column(Modifier.fillMaxWidth().padding(top = 10.dp, bottom = 7.dp)) {
        Text("ACESSO RÁPIDO", Modifier.padding(start = 18.dp, bottom = 7.dp), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, fontWeight = FontWeight.Bold)
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 14.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            actions.forEach { action ->
                Surface(
                    onClick = { onChoose(action.prompt) },
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.surface,
                    border = androidx.compose.foundation.BorderStroke(1.dp, action.tint.copy(alpha = 0.35f))
                ) {
                    Row(Modifier.padding(horizontal = 11.dp, vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(action.icon, null, tint = action.tint, modifier = Modifier.size(21.dp))
                        Spacer(Modifier.width(8.dp))
                        Column {
                            Text(action.title, color = MaterialTheme.colorScheme.onSurface, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold)
                            Text(action.subtitle, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MessageBubble(message: ChatMessage) {
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = if (message.fromUser) Arrangement.End else Arrangement.Start,
        verticalAlignment = Alignment.Bottom
    ) {
        if (!message.fromUser) {
            Box(Modifier.size(28.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Color(0xFF236BCE), Color(0xFF7546C8)))), contentAlignment = Alignment.Center) {
                Text("Q", color = Color.White, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.width(7.dp))
        }
        Surface(
            color = if (message.fromUser) Color(0xFF344DCB) else MaterialTheme.colorScheme.surface,
            shape = RoundedCornerShape(19.dp, 19.dp, if (message.fromUser) 5.dp else 19.dp, 19.dp),
            border = if (message.fromUser) null else androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF222F4B))
        ) {
            Text(message.text, color = Color.White, modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp), style = MaterialTheme.typography.bodyMedium)
        }
    }
}

@Composable
private fun TypingIndicator() {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(28.dp).clip(CircleShape).background(MaterialTheme.colorScheme.surfaceVariant), contentAlignment = Alignment.Center) { Text("Q", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold) }
        Spacer(Modifier.width(7.dp))
        Surface(color = MaterialTheme.colorScheme.surface, shape = RoundedCornerShape(18.dp)) {
            Text("Pensando…", color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(horizontal = 14.dp, vertical = 9.dp), style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun Composer(value: String, onValueChange: (String) -> Unit, enabled: Boolean, onImport: () -> Unit, onSend: () -> Unit) {
    Surface(color = MaterialTheme.colorScheme.background, shadowElevation = 8.dp) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.Bottom) {
            Surface(shape = CircleShape, color = MaterialTheme.colorScheme.surfaceVariant) {
                IconButton(onClick = onImport, enabled = enabled, modifier = Modifier.size(45.dp)) { Icon(Icons.Default.Add, "Importar conhecimento", tint = MaterialTheme.colorScheme.onSurfaceVariant) }
            }
            Spacer(Modifier.width(8.dp))
            Surface(modifier = Modifier.weight(1f), shape = RoundedCornerShape(22.dp), color = MaterialTheme.colorScheme.surface, border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF2C3B5D))) {
                TextField(
                    value = value, onValueChange = onValueChange, enabled = enabled,
                    placeholder = { Text("Converse com a QYLARA…") }, modifier = Modifier.fillMaxWidth(), maxLines = 4,
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent, disabledContainerColor = Color.Transparent,
                        focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent, disabledIndicatorColor = Color.Transparent
                    )
                )
            }
            Spacer(Modifier.width(8.dp))
            Surface(shape = CircleShape, color = if (value.isNotBlank() && enabled) Color(0xFF4D5DFF) else MaterialTheme.colorScheme.surfaceVariant) {
                IconButton(onClick = onSend, enabled = enabled && value.isNotBlank(), modifier = Modifier.size(45.dp)) {
                    Icon(Icons.Default.Send, "Enviar", tint = if (value.isNotBlank() && enabled) Color.White else MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}
