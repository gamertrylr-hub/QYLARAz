package ai.qylara.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val QylaraColors = darkColorScheme(
    primary = Color(0xFF8B7CFF),
    onPrimary = Color.White,
    secondary = Color(0xFF5DE1C7),
    background = Color(0xFF080B12),
    onBackground = Color(0xFFF4F5F7),
    surface = Color(0xFF101521),
    onSurface = Color(0xFFF4F5F7),
    surfaceVariant = Color(0xFF181E2B),
    onSurfaceVariant = Color(0xFFA8B0C0),
    outline = Color(0xFF2B3445)
)

@Composable
fun QylaraTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = QylaraColors, content = content)
}
