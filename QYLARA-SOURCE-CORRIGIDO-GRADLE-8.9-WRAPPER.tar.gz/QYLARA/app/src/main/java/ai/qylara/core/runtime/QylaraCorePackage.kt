package ai.qylara.core.runtime

import android.content.Context
import org.json.JSONObject

/** Validates the local QYLARA artifact before native inference. */
object QylaraCorePackage {
    private const val REQUIRED_FORMAT = "qylara-core"
    private const val REQUIRED_VERSION = 5

    fun inspect(context: Context, artifact: QylaraCoreArtifact): QylaraCorePackageInfo {
        val manifestPath = "${artifact.assetDirectory}/manifest.json"
        val json = context.assets.open(manifestPath).bufferedReader().use { JSONObject(it.readText()) }
        require(json.optString("format") == REQUIRED_FORMAT) { "Formato de Core inválido." }
        require(json.optInt("version") == REQUIRED_VERSION) { "Versão do Core incompatível." }

        val files = json.optJSONObject("artifact") ?: JSONObject()
        val requirements = json.optJSONObject("requirements") ?: JSONObject()
        val tokenizer = files.optString("tokenizer", "tokenizer.qytok")
        val weights = files.optString("weights", "weights.qyweights")
        val generation = files.optString("generation", "generation.json")

        val tokenizerPresent = assetExists(context, "${artifact.assetDirectory}/$tokenizer")
        val weightsPresent = assetExists(context, "${artifact.assetDirectory}/$weights")
        val generationPresent = assetExists(context, "${artifact.assetDirectory}/$generation")
        val nativePresent = nativeLibraryAvailable()

        return QylaraCorePackageInfo(
            state = json.optString("state"),
            hasTokenizer = tokenizerPresent,
            hasWeights = weightsPresent,
            hasNativeExecutor = nativePresent,
            hasGenerationConfig = generationPresent,
            trainingExamplesEmbedded = false,
            requiresTokenizer = requirements.optBoolean("tokenizer", true),
            requiresWeights = requirements.optBoolean("weights", true),
            requiresNativeExecutor = requirements.optBoolean("nativeExecutor", true),
            behavioralValidationRequired = requirements.optBoolean("behavioralValidation", true)
        )
    }

    private fun assetExists(context: Context, path: String): Boolean =
        runCatching { context.assets.open(path).use { } }.isSuccess

    private fun nativeLibraryAvailable(): Boolean =
        runCatching { System.loadLibrary("qylara_core") }.isSuccess
}

data class QylaraCorePackageInfo(
    val state: String,
    val hasTokenizer: Boolean,
    val hasWeights: Boolean,
    val hasNativeExecutor: Boolean,
    val hasGenerationConfig: Boolean,
    val trainingExamplesEmbedded: Boolean,
    val requiresTokenizer: Boolean,
    val requiresWeights: Boolean,
    val requiresNativeExecutor: Boolean,
    val behavioralValidationRequired: Boolean
) {
    val executable: Boolean
        get() = (!requiresTokenizer || hasTokenizer) &&
            (!requiresWeights || hasWeights) &&
            (!requiresNativeExecutor || hasNativeExecutor) &&
            hasGenerationConfig &&
            !trainingExamplesEmbedded
}
