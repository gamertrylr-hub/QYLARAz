package ai.qylara.core.runtime

import android.content.Context
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL

/** Owns the Gemma weights inside QYLARA's private app storage. */
class GemmaModelStore(context: Context) {
    private val app = context.applicationContext
    private val modelDir = File(app.filesDir, "qylara_models/gemma4-e2b").apply { mkdirs() }
    val modelFile: File get() = File(modelDir, MODEL_NAME)
    val isInstalled: Boolean get() = modelFile.isFile && modelFile.length() >= MIN_EXPECTED_BYTES

    /** Downloads only when explicitly requested by the user. Run on an IO dispatcher. */
    fun download(onProgress: (Long, Long) -> Unit = { _, _ -> }) {
        if (isInstalled) return
        val partial = File(modelDir, "$MODEL_NAME.part")
        var connection: HttpURLConnection? = null
        try {
            connection = (URL(MODEL_URL).openConnection() as HttpURLConnection).apply {
                connectTimeout = 30_000
                readTimeout = 60_000
                instanceFollowRedirects = true
                setRequestProperty("User-Agent", "QYLARA-Android")
                connect()
            }
            check(connection.responseCode in 200..299) {
                "Download do Gemma recusado (HTTP ${connection.responseCode}). Verifique o acesso/licença do modelo e tente novamente."
            }
            val total = connection.contentLengthLong
            FileOutputStream(partial).use { out ->
                connection.inputStream.use { input ->
                    val buffer = ByteArray(1024 * 256)
                    var done = 0L
                    while (true) {
                        val n = input.read(buffer)
                        if (n < 0) break
                        out.write(buffer, 0, n)
                        done += n
                        onProgress(done, total)
                    }
                    out.fd.sync()
                }
            }
            check(partial.length() >= MIN_EXPECTED_BYTES) {
                "Arquivo recebido incompleto (${partial.length()} bytes). O modelo não foi instalado."
            }
            if (modelFile.exists()) modelFile.delete()
            check(partial.renameTo(modelFile)) { "Não foi possível finalizar a instalação do modelo." }
        } catch (e: Exception) {
            partial.delete()
            throw e
        } finally {
            connection?.disconnect()
        }
    }

    companion object {
        const val MODEL_NAME = "gemma-4-E2B-it.litertlm"
        // The official mobile artifact is about 2.58 GB; reject HTML/login pages and truncated downloads.
        private const val MIN_EXPECTED_BYTES = 1_000_000_000L
        const val MODEL_URL = "https://huggingface.co/litert-community/gemma-4-E2B-it-litert-lm/resolve/main/gemma-4-E2B-it.litertlm"
    }
}
