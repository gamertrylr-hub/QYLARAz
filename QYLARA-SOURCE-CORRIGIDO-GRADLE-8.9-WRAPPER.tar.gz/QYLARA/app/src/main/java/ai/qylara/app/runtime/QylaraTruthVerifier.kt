package ai.qylara.app.runtime

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.Normalizer
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Evidence triage, not an oracle: it reports evidence strength and uncertainty, never absolute truth. */
internal class QylaraTruthVerifier(context: Context, private val web: QylaraWebResearch) {
    private val historyFile = File(context.filesDir, "qylara_knowledge/verification_history.json")
    private val lock = Any()

    suspend fun verify(claim: String): String {
        val cleanClaim = cleanRequest(claim)
        if (cleanClaim.length < 8) return "Diga a afirmação completa que você quer verificar."
        val results = runCatching { web.searchResults(cleanClaim, 8) }.getOrElse {
            return "STATUS: NÃO VERIFICADO\nNão consegui consultar fontes online agora. Não vou classificar a afirmação como verdadeira ou falsa sem evidências."
        }
        if (results.isEmpty()) {
            save(cleanClaim, "NÃO VERIFICADO", emptyList())
            return "STATUS: NÃO VERIFICADO\nNão encontrei resultados suficientes para avaliar essa afirmação. Isso não significa que seja falsa."
        }

        val independentDomains = results.mapNotNull { domain(it.url) }.distinct()
        val claimTerms = tokens(cleanClaim).filter { it.length > 2 }.toSet()
        val scored = results.map { result ->
            val text = normalize(result.title + " " + result.snippet)
            val overlap = claimTerms.intersect(tokens(text).toSet()).size
            val denial = denialSignals.any { text.contains(it) }
            val confirmation = confirmationSignals.any { text.contains(it) }
            Evidence(result, overlap, denial, confirmation)
        }
        val relevant = scored.filter { it.overlap >= minOf(2, claimTerms.size.coerceAtLeast(1)) }
        val contradictions = relevant.count { it.denial }
        val confirmations = relevant.count { it.confirmation }
        val status = when {
            relevant.isEmpty() -> "EVIDÊNCIA INSUFICIENTE"
            contradictions > 0 && confirmations > 0 -> "EVIDÊNCIAS MISTAS / CONFLITO"
            confirmations >= 2 && independentDomains.size >= 2 -> "INDÍCIOS DE APOIO — AINDA PRECISA DE CONFIRMAÇÃO"
            contradictions >= 2 && independentDomains.size >= 2 -> "INDÍCIOS CONTRÁRIOS — AINDA PRECISA DE CONFIRMAÇÃO"
            else -> "NÃO VERIFICADO"
        }
        save(cleanClaim, status, results)

        return buildString {
            append("AVALIAÇÃO DE EVIDÊNCIAS: ").append(status).append("\n\n")
            append("Afirmação analisada: ").append(cleanClaim).append("\n")
            append("Resultados consultados: ").append(results.size).append("; domínios distintos: ").append(independentDomains.size).append(".\n")
            append("Sinais encontrados: ").append(relevant.size).append(" resultado(s) com termos relacionados; ")
            append(confirmations).append(" com sinais textuais de apoio e ").append(contradictions).append(" com sinais de contestação.\n\n")
            append("Limite: estes sinais vêm de títulos e resumos de busca; não provam a verdade por si só. A QYLARA não deve declarar uma afirmação verdadeira ou falsa sem ler e avaliar as evidências primárias adequadas.\n\n")
            append("FONTES PARA CONFERÊNCIA:\n")
            results.take(6).forEachIndexed { i, item ->
                append(i + 1).append(". ").append(item.title).append("\n")
                if (item.snippet.isNotBlank()) append(item.snippet).append("\n")
                append(item.url).append("\n\n")
            }
        }.trim()
    }

    fun recentHistory(limit: Int = 5): String = synchronized(lock) {
        val entries = runCatching { JSONArray(historyFile.readText(Charsets.UTF_8)) }.getOrDefault(JSONArray())
        if (entries.length() == 0) return@synchronized "Ainda não há verificações salvas."
        (0 until entries.length()).toList().asReversed().take(limit).joinToString("\n\n") { i ->
            val e = entries.getJSONObject(i)
            "${e.optString("status")} — ${e.optString("claim")} (${e.optString("date")})"
        }
    }

    private fun save(claim: String, status: String, results: List<QylaraWebResearch.Result>) = synchronized(lock) {
        historyFile.parentFile?.mkdirs()
        val entries = runCatching { JSONArray(historyFile.readText(Charsets.UTF_8)) }.getOrDefault(JSONArray())
        val sources = JSONArray()
        results.take(8).forEach { sources.put(JSONObject().put("title", it.title).put("url", it.url).put("snippet", it.snippet)) }
        entries.put(JSONObject()
            .put("claim", claim).put("status", status)
            .put("date", SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.ROOT).format(Date()))
            .put("sources", sources))
        while (entries.length() > 300) entries.remove(0)
        val temp = File(historyFile.parentFile, "verification_history.json.tmp")
        temp.writeText(entries.toString(2), Charsets.UTF_8)
        if (!temp.renameTo(historyFile)) { historyFile.writeText(temp.readText(Charsets.UTF_8), Charsets.UTF_8); temp.delete() }
    }

    private fun cleanRequest(value: String): String = value.trim()
        .replace(Regex("(?i)^(verifique|verificar|confira|confirme|isso é verdade[:?]?|é verdade que)\\s*"), "")
        .trim().trimEnd('?', '.', ' ')

    private fun domain(url: String): String? = runCatching { java.net.URI(url).host?.removePrefix("www.")?.lowercase(Locale.ROOT) }.getOrNull()
    private fun tokens(value: String) = normalize(value).split(Regex("[^a-z0-9]+" )).filter { it.isNotBlank() }
    private fun normalize(value: String) = Normalizer.normalize(value.lowercase(Locale.ROOT), Normalizer.Form.NFD).replace(Regex("\\p{Mn}+"), "")

    private data class Evidence(val result: QylaraWebResearch.Result, val overlap: Int, val denial: Boolean, val confirmation: Boolean)

    private val denialSignals = listOf("falso", "falsa", "nao e verdade", "desmentido", "desmentida", "fact check", "checagem", "mito", "inveridico", "inveridica", "sem evidencias")
    private val confirmationSignals = listOf("confirmado", "confirmada", "comprovado", "comprovada", "evidencias mostram", "estudo concluiu", "dados oficiais", "documento oficial")
}
