package ai.qylara.app.runtime

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.Normalizer
import java.util.Locale

/** Private, explicit-consent memory. Stores user-approved facts, never trains or edits neural weights. */
internal class QylaraUserMemory(context: Context) {
    private val file = File(context.filesDir, "qylara_memory/user_memory.json")
    private val lock = Any()

    data class CommandResult(val handled: Boolean, val message: String? = null)

    fun handleExplicitCommand(prompt: String): CommandResult {
        val trimmed = prompt.trim()
        val lower = trimmed.lowercase(Locale.ROOT)
        val savePrefixes = listOf("memorize:", "memorize:", "lembre que:", "lembre-se que:", "guarde na memória:", "guarde na memoria:")
        val forgetPrefixes = listOf("esqueça:", "esqueca:", "apague da memória:", "apague da memoria:")
        val savePrefix = savePrefixes.firstOrNull { lower.startsWith(it) }
        if (savePrefix != null) {
            val fact = trimmed.drop(savePrefix.length).trim()
            if (fact.length < 3) return CommandResult(true, "Diga o que você quer que eu memorize depois de ‘lembre que:’.")
            if (fact.length > 1200) return CommandResult(true, "Essa memória é muito longa. Resuma para até 1.200 caracteres.")
            synchronized(lock) {
                val entries = readEntries()
                val key = normalize(fact)
                if (entries.none { normalize(it) == key }) entries.put(fact)
                writeEntries(entries)
            }
            return CommandResult(true, "Memória salva neste dispositivo. Ela poderá ser usada nas próximas conversas. Para removê-la, diga ‘esqueça:’ seguido do conteúdo.")
        }
        val forgetPrefix = forgetPrefixes.firstOrNull { lower.startsWith(it) }
        if (forgetPrefix != null) {
            val target = trimmed.drop(forgetPrefix.length).trim()
            if (target.isBlank()) return CommandResult(true, "Informe qual memória deseja apagar depois de ‘esqueça:’.")
            synchronized(lock) {
                val entries = readEntries()
                val before = entries.length()
                val kept = JSONArray()
                for (i in 0 until entries.length()) {
                    val value = entries.optString(i)
                    if (!normalize(value).contains(normalize(target)) && !normalize(target).contains(normalize(value))) kept.put(value)
                }
                writeEntries(kept)
                return CommandResult(true, if (kept.length() < before) "Memória correspondente removida deste dispositivo." else "Não encontrei uma memória correspondente para remover.")
            }
        }
        return CommandResult(false)
    }

    fun relevantContext(prompt: String, maxItems: Int = 6): String? = synchronized(lock) {
        val entries = readEntries()
        if (entries.length() == 0) return@synchronized null
        val terms = tokens(prompt).filter { it.length > 2 }.toSet()
        val ranked = (0 until entries.length()).map { entries.optString(it) }
            .map { fact -> fact to terms.intersect(tokens(fact).toSet()).size }
            .filter { it.second > 0 }
            .sortedByDescending { it.second }
            .take(maxItems)
            .map { it.first }
        if (ranked.isEmpty()) null else ranked.joinToString("\n") { "- $it" }
    }

    fun count(): Int = synchronized(lock) { readEntries().length() }

    private fun readEntries(): JSONArray = runCatching {
        if (!file.exists()) JSONArray() else JSONObject(file.readText(Charsets.UTF_8)).optJSONArray("items") ?: JSONArray()
    }.getOrDefault(JSONArray())

    private fun writeEntries(entries: JSONArray) {
        file.parentFile?.mkdirs()
        val temp = File(file.parentFile, "user_memory.json.tmp")
        temp.writeText(JSONObject().put("version", 1).put("items", entries).toString(2), Charsets.UTF_8)
        if (!temp.renameTo(file)) {
            file.writeText(temp.readText(Charsets.UTF_8), Charsets.UTF_8)
            temp.delete()
        }
    }

    private fun tokens(value: String) = normalize(value).split(Regex("[^a-z0-9]+" )).filter { it.isNotBlank() }
    private fun normalize(value: String) = Normalizer.normalize(value.lowercase(Locale.ROOT), Normalizer.Form.NFD).replace(Regex("\\p{Mn}+"), "")
}
