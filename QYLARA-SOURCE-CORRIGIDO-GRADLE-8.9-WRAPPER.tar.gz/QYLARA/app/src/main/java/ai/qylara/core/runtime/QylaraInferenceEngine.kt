package ai.qylara.core.runtime

/** Runtime-only contract for the QYLARA-owned neural Core. */
interface QylaraInferenceEngine {
    suspend fun generate(prompt: String, maxTokens: Int = 256): String
    fun close()
}

data class QylaraCoreArtifact(
    val assetDirectory: String,
    val contextTokens: Int
)

object QylaraCoreCatalog {
    val standard = QylaraCoreArtifact(
        assetDirectory = "models/qylara-core",
        contextTokens = 1024
    )
}
