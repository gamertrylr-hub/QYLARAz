#include <jni.h>
#include <android/asset_manager_jni.h>
#include <android/asset_manager.h>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <string>
#include <vector>
#include <algorithm>
#include <random>
#include <limits>
#include <stdexcept>

namespace {
struct Hdr { char magic[4]; uint32_t version,vocab,ctx,dim,layers,heads,ff; };
static float half(uint16_t h){
    uint32_t s=(h>>15)&1,e=(h>>10)&31,f=h&1023;
    if(e==0) return (s?-1.f:1.f)*std::ldexp((float)f,-24);
    if(e==31) return f?NAN:(s?-INFINITY:INFINITY);
    return (s?-1.f:1.f)*std::ldexp(1.f+(float)f/1024.f,(int)e-15);
}
static bool read_all(AAsset* a, void* p, size_t n){ return AAsset_read(a,p,n)==(int)n; }
static std::vector<float> read_tensor(AAsset* a,size_t n){
    std::vector<uint16_t> h(n); std::vector<float> v(n);
    if(!read_all(a,h.data(),n*2)) throw std::runtime_error("weights truncated");
    for(size_t i=0;i<n;i++) v[i]=half(h[i]);
    return v;
}
static void mat(const std::vector<float>& w,const float* x,float* y,int out,int in){
    for(int o=0;o<out;o++){ const float* r=w.data()+size_t(o)*in; float s=0; for(int i=0;i<in;i++) s+=r[i]*x[i]; y[o]=s; }
}
static void rms(const std::vector<float>& w,const float* x,float* y,int n){
    double s=0; for(int i=0;i<n;i++) s+=(double)x[i]*x[i]; float z=1.f/std::sqrt((float)(s/n)+1e-6f);
    for(int i=0;i<n;i++) y[i]=x[i]*z*w[i];
}
static float silu(float x){return x/(1.f+std::exp(-x));}
struct Layer {std::vector<float> n1,q,k,v,o,n2,f1,f2,f3;};
struct Model {
    Hdr h{}; std::vector<float> emb,norm; std::vector<Layer> L;
    void load(AAsset* a){
        if(!read_all(a,&h,sizeof(h)) || std::memcmp(h.magic,"QYWT",4)!=0 || h.version!=1) throw std::runtime_error("bad qyweights");
        emb=read_tensor(a,size_t(h.vocab)*h.dim); L.resize(h.layers);
        for(auto& z:L){ z.n1=read_tensor(a,h.dim); z.q=read_tensor(a,size_t(h.dim)*h.dim); z.k=read_tensor(a,size_t(h.dim)*h.dim); z.v=read_tensor(a,size_t(h.dim)*h.dim); z.o=read_tensor(a,size_t(h.dim)*h.dim); z.n2=read_tensor(a,h.dim); z.f1=read_tensor(a,size_t(h.ff)*h.dim); z.f2=read_tensor(a,size_t(h.dim)*h.ff); z.f3=read_tensor(a,size_t(h.ff)*h.dim); }
        norm=read_tensor(a,h.dim);
    }
};
static void rope(float* q,float* k,int heads,int hd,int pos,float theta){
    for(int head=0;head<heads;head++) for(int i=0;i<hd;i+=2){
        float inv=std::pow(theta,-float(i)/float(hd)); float a=pos*inv, c=std::cos(a),s=std::sin(a);
        float* qp=q+head*hd+i; float* kp=k+head*hd+i; float q0=qp[0],q1=qp[1],k0=kp[0],k1=kp[1];
        qp[0]=q0*c-q1*s; qp[1]=q0*s+q1*c; kp[0]=k0*c-k1*s; kp[1]=k0*s+k1*c;
    }
}
static int sample(std::vector<float>& logits,float temp,float topP,std::mt19937& rng,const std::vector<int>& history){
    const int n=logits.size();
    for(int id:history) logits[id]-=0.18f;
    float inv=1.f/std::max(temp,0.05f), mx=*std::max_element(logits.begin(),logits.end());
    std::vector<std::pair<float,int>> p; p.reserve(n); double sum=0;
    for(int i=0;i<n;i++){ float e=std::exp((logits[i]-mx)*inv); p.push_back({e,i}); sum+=e; }
    std::sort(p.begin(),p.end(),[](auto&a,auto&b){return a.first>b.first;});
    double cut=sum*std::min(std::max(topP,0.05f),1.f), acc=0; std::vector<std::pair<double,int>> keep;
    for(auto [e,i]:p){ acc+=e; keep.push_back({e,i}); if(acc>=cut) break; }
    std::uniform_real_distribution<double> u(0,acc), pick(u(rng)); double r=pick;
    for(auto [e,i]:keep){ if((r-=e)<=0) return i; }
    return keep.back().second;
}
static std::string generate(AAssetManager* mgr,const std::string& assetDir,const std::string& prompt,int maxNew){
    std::string path=assetDir+"/weights.qyweights"; AAsset* a=AAssetManager_open(mgr,path.c_str(),AASSET_MODE_BUFFER); if(!a) throw std::runtime_error("weights.qyweights missing");
    Model m; m.load(a); AAsset_close(a);
    if(m.h.vocab!=256 || m.h.dim% m.h.heads!=0) throw std::runtime_error("unsupported model config");
    std::vector<unsigned char> bytes(prompt.begin(),prompt.end());
    int ctx=m.h.ctx; if((int)bytes.size()>ctx) bytes.erase(bytes.begin(),bytes.end()-ctx);
    const int d=m.h.dim, hd=d/m.h.heads;
    std::vector<std::vector<float>> K(m.h.layers),V(m.h.layers); for(int l=0;l<(int)m.h.layers;l++){K[l].resize(size_t(ctx)*d);V[l].resize(size_t(ctx)*d);}
    std::vector<float> x(d),h(d),q(d),k(d),v(d),y(d),tmp(m.h.ff),gate(m.h.ff),logits(256); std::vector<int> hist;
    auto step=[&](int id,int pos){
        std::copy(m.emb.begin()+size_t(id)*d,m.emb.begin()+size_t(id+1)*d,x.begin());
        for(int l=0;l<(int)m.h.layers;l++){
            rms(m.L[l].n1,x.data(),h.data(),d); mat(m.L[l].q,h.data(),q.data(),d,d); mat(m.L[l].k,h.data(),k.data(),d,d); mat(m.L[l].v,h.data(),v.data(),d,d);
            rope(q.data(),k.data(),m.h.heads,hd,pos,10000.f); std::copy(k.begin(),k.end(),K[l].begin()+size_t(pos)*d); std::copy(v.begin(),v.end(),V[l].begin()+size_t(pos)*d);
            std::fill(y.begin(),y.end(),0.f); float scale=1.f/std::sqrt((float)hd);
            for(int hh=0;hh<(int)m.h.heads;hh++){
                std::vector<float> scores(pos+1); float mx=-INFINITY; for(int t=0;t<=pos;t++){float s=0; for(int j=0;j<hd;j++) s+=q[hh*hd+j]*K[l][size_t(t)*d+hh*hd+j]; scores[t]=s*scale; mx=std::max(mx,scores[t]);}
                double den=0; for(float&s:scores){s=std::exp(s-mx);den+=s;} for(float&s:scores)s/=den;
                for(int t=0;t<=pos;t++) for(int j=0;j<hd;j++) y[hh*hd+j]+=scores[t]*V[l][size_t(t)*d+hh*hd+j];
            }
            mat(m.L[l].o,y.data(),tmp.data(),d,d); for(int i=0;i<d;i++) x[i]+=tmp[i];
            rms(m.L[l].n2,x.data(),h.data(),d); mat(m.L[l].f1,h.data(),tmp.data(),m.h.ff,d); mat(m.L[l].f3,h.data(),gate.data(),m.h.ff,d); for(int i=0;i<m.h.ff;i++) tmp[i]=silu(tmp[i])*gate[i]; mat(m.L[l].f2,tmp.data(),y.data(),d,m.h.ff); for(int i=0;i<d;i++) x[i]+=y[i];
        }
        rms(m.norm,x.data(),h.data(),d); for(int i=0;i<256;i++){float s=0; for(int j=0;j<d;j++)s+=h[j]*m.emb[size_t(i)*d+j]; logits[i]=s;}
    };
    for(int pos=0;pos<(int)bytes.size();pos++){step(bytes[pos],pos); hist.push_back(bytes[pos]);}
    std::string out; std::mt19937 rng(20261007); for(int n=0;n<maxNew;n++){int id=sample(logits,0.7f,0.9f,rng,hist); out.push_back((char)id); hist.push_back(id); int pos=(int)hist.size()-1; if(pos>=ctx) break; step(id,pos);}
    return out;
}
}
extern "C" JNIEXPORT jstring JNICALL Java_ai_qylara_core_runtime_NativeQylaraInferenceEngine_generateNative(JNIEnv* env,jobject,jobject assetManager,jstring jdir,jstring jprompt,jint maxNew){
    try{ AAssetManager* mgr=AAssetManager_fromJava(env,assetManager); const char* d=env->GetStringUTFChars(jdir,nullptr); const char* p=env->GetStringUTFChars(jprompt,nullptr); std::string s=generate(mgr,d,p,maxNew); env->ReleaseStringUTFChars(jdir,d); env->ReleaseStringUTFChars(jprompt,p); std::u16string u16; for(size_t i=0;i<s.size();){ unsigned char c=(unsigned char)s[i++]; uint32_t cp=0; if(c<0x80) cp=c; else if((c&0xE0)==0xC0 && i<s.size()){ unsigned char c1=(unsigned char)s[i++]; if((c1&0xC0)!=0x80){cp=0xFFFD;} else cp=((c&0x1F)<<6)|(c1&0x3F); } else if((c&0xF0)==0xE0 && i+1<s.size()){ unsigned char c1=(unsigned char)s[i++],c2=(unsigned char)s[i++]; if((c1&0xC0)||(c2&0xC0)) cp=0xFFFD; else cp=((c&0x0F)<<12)|((c1&0x3F)<<6)|(c2&0x3F); } else if((c&0xF8)==0xF0 && i+2<s.size()){ unsigned char c1=(unsigned char)s[i++],c2=(unsigned char)s[i++],c3=(unsigned char)s[i++]; if((c1&0xC0)||(c2&0xC0)||(c3&0xC0)) cp=0xFFFD; else cp=((c&7)<<18)|((c1&0x3F)<<12)|((c2&0x3F)<<6)|(c3&0x3F); } else cp=0xFFFD; if(cp<=0xFFFF) u16.push_back((char16_t)cp); else { cp-=0x10000; u16.push_back((char16_t)(0xD800+(cp>>10))); u16.push_back((char16_t)(0xDC00+(cp&0x3FF))); } } return env->NewString((const jchar*)u16.data(), (jsize)u16.size()); }
    catch(const std::exception& e){ return env->NewStringUTF((std::string("[QYLARA_NATIVE_ERROR] ")+e.what()).c_str()); }
}
